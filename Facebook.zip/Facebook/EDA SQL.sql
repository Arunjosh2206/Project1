#/1/List out all the users in database//
select username from users; 

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#/2/list out Top 10 oldest userss of 2022//
CREATE INDEX idx_created_at ON facebook.users (created_at);
SELECT id, username, created_at
FROM facebook.users
ORDER BY created_at ASC
LIMIT 10;

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#/3/*Ques.3 The day of the week most users register on*/
SELECT 
    day_of_week,
    COUNT(*) AS total_number_of_registrations
FROM
    (SELECT 
        DAYNAME(created_at) AS day_of_week
    FROM
        facebook.users) as dor
GROUP BY day_of_week
ORDER BY total_number_of_registrations DESC;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#/4/ How has the number of new users signing up each month changed over time??/

SELECT DATE_FORMAT(created_at, '%Y-%m') AS month, COUNT(*) AS new_user_count
FROM users
GROUP BY month
ORDER BY month;

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#/5/*Ques. The users who have never posted a photo*/

    #Approach 1:
    SELECT u.username
FROM facebook.users u
WHERE NOT EXISTS (
    SELECT 1
    FROM facebook.photos p
    WHERE p.user_id = u.id
);

  #Approach 2:
SELECT 
    u.username
FROM
    facebook.users u
        LEFT JOIN
    facebook.photos p ON p.user_id = u.id
WHERE
    p.id IS NULL;

 
# APPROACH 3:
 
SELECT u.username
FROM facebook.users u
WHERE NOT EXISTS (
    SELECT 1
    FROM facebook.photos p
    WHERE p.user_id = u.id
);


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#/6/ The number of photos posted by most active users*/

#APPROACH 1:

SELECT 
	u.username AS 'Username',
    COUNT(p.image_url) AS 'Number of Posts'
FROM
    FACEBOOK.users u
        JOIN
    FACEBOOK.photos p ON u.id = p.user_id
GROUP BY u.id
ORDER BY 2 DESC
LIMIT 5;

#APPROACH 2:
#USING CTE
WITH PostCounts AS (
     SELECT
         u.username AS `Username`,
         COUNT(p.image_url) AS `Number of Posts`,
         ROW_NUMBER() OVER (ORDER BY COUNT(p.image_url) DESC) AS PostRank
     FROM
         FACEBOOK.users u
     JOIN
         FACEBOOK.photos p ON u.id = p.user_id
     GROUP BY u.id
 )
 SELECT `Username`, `Number of Posts`
 FROM PostCounts
 WHERE PostRank <= 5;
 
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

 
#/7/ The total number of users with posts*/
SELECT COUNT(*) AS total_users_with_posts
FROM FACEBOOK.users u
WHERE EXISTS (
    SELECT 1
    FROM FACEBOOK.photos p
    WHERE p.user_id = u.id
);


#APPROACH 2:
SELECT 
    COUNT(DISTINCT (u.id)) AS total_users_with_posts
FROM
    FACEBOOK.users u
        JOIN
    FACEBOOK.photos p ON u.id = p.user_id;

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#/8/ The usernames with numbers as ending*/

#APPROACH 1
SELECT 
    id, username
FROM
    FACEBOOK.users
WHERE
    username REGEXP '[$0-9]';

#APPROACH 2
SELECT id, username
FROM FACEBOOK.users
WHERE username LIKE '%0%' OR
      username LIKE '%1%' OR
      username LIKE '%2%' OR
      username LIKE '%3%' OR
      username LIKE '%4%' OR
      username LIKE '%5%' OR
      username LIKE '%6%' OR
      username LIKE '%7%' OR
      username LIKE '%8%' OR
      username LIKE '%9%';

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#/9/ The number of usernames that start with A*/

#Approach 1
SELECT COUNT(id)
FROM facebook.users
WHERE username LIKE 'A%';

#Approach 2

SELECT 
    count(id)
FROM
    facebook.users
WHERE
    username REGEXP '^[A]';
    
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

/*10/The most popular tag names by usage*/

#Approach 1
SELECT 
    t.tag_name, COUNT(tag_name) AS usage_count
FROM
    facebook.tags t
        JOIN
    facebook.photo_tags pt ON t.id = pt.tag_id
GROUP BY t.id
ORDER BY usage_count DESC
LIMIT 10;


#Approach 2

SELECT 
    t.tag_name, 
    (SELECT COUNT(*) FROM facebook.photo_tags pt WHERE pt.tag_id = t.id) AS usage_count
FROM
    facebook.tags t
ORDER BY usage_count DESC
LIMIT 10;


----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#/11/ The most popular tag names by likes*/



#Approach 1
WITH TagLikes AS (
    SELECT
        t.tag_name AS 'Tag Name',
        COUNT(l.photo_id) AS 'Likes',
        ROW_NUMBER() OVER (ORDER BY COUNT(l.photo_id) DESC) AS LikeRank
    FROM
        facebook.photo_tags pt
    JOIN
        facebook.likes l ON l.photo_id = pt.photo_id
    JOIN
        facebook.tags t ON pt.tag_id = t.id
    GROUP BY t.tag_name
 )

SELECT `Tag Name`, `Likes`
FROM TagLikes
WHERE LikeRank <= 10;


#Approach 2(Most effective) 
SELECT 
    t.tag_name AS 'Tag Name',
    COUNT(l.photo_id) AS 'Likes'
FROM
    facebook.photo_tags pt
        JOIN
   facebook.likes l ON l.photo_id = pt.photo_id
        JOIN
    facebook.tags t ON pt.tag_id = t.id
GROUP BY 1
ORDER BY 2 DESC
LIMIT 10;
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------


#/12/ The users who have liked every single photo on the site*/

#Approach 1(most efficient)
SELECT 
    u.id,
    u.username,
    (SELECT COUNT(*) FROM facebook.likes l WHERE l.user_id = u.id) AS total_likes
FROM
    facebook.users u
WHERE
    (SELECT COUNT(*) FROM facebook.likes l WHERE l.user_id = u.id) = (SELECT COUNT(*) FROM facebook.photos);
    
#Approach 2

SELECT 
    u.id, u.username, COUNT(l.user_id) AS total_likes
FROM
    facebook.users u
        JOIN
     facebook.likes l ON u.id = l.user_id
GROUP BY u.id
HAVING total_likes = (SELECT 
        COUNT(*)
    FROM
        facebook.photos);
        
        
        
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#/13/ Total number of users without comments*/

#Approach 1(Most efficient)

SELECT COUNT(*) AS users_without_comments
FROM facebook.users u
LEFT JOIN facebook.comments c ON u.id = c.user_id
WHERE c.comment_text IS NULL;

#Approach 2

SELECT 
    COUNT(*) AS users_without_comments
FROM
    (SELECT 
        u.username, c.comment_text
    FROM
        facebook.users u
    LEFT JOIN facebook.comments c ON u.id = c.user_id
    GROUP BY u.id , c.comment_text
    HAVING comment_text IS NULL) AS users;      



  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   #/14/ The percentage of users who have either never commented on a photo or likes every photo*/
   
   #Approach 1(Most efficient)
     
WITH UsersWithoutComments AS (
    SELECT COUNT(DISTINCT u.id) AS count_users_without_comments
    FROM facebook.users u
    LEFT JOIN facebook.comments c ON u.id = c.user_id
    WHERE c.comment_text IS NULL
),
UsersLikingEveryPhoto AS (
    SELECT COUNT(DISTINCT u.id) AS count_users_liking_every_photo
    FROM facebook.users u
    WHERE (
        SELECT COUNT(*) 
        FROM facebook.likes l 
        WHERE l.user_id = u.id
    ) = (
        SELECT COUNT(*) 
        FROM facebook.photos p
    )
),
TotalUsers AS (
    SELECT COUNT(*) AS total_users
    FROM facebook.users
)
SELECT 
    UsersWithoutComments.count_users_without_comments AS 'Users without comments',
    (UsersWithoutComments.count_users_without_comments / TotalUsers.total_users) * 100 AS 'Percentage Users without comments',
    UsersLikingEveryPhoto.count_users_liking_every_photo AS 'Users liking every photo',
    (UsersLikingEveryPhoto.count_users_liking_every_photo / TotalUsers.total_users) * 100 AS 'Percentage Users liking every photo'
FROM
    UsersWithoutComments, UsersLikingEveryPhoto, TotalUsers;
    
    
   #Approach 2
   
    
        SELECT 
    table1.total_1 AS 'Users who never commented',
    (table1.total_1 / (SELECT COUNT(*) FROM facebook.users u)) * 100 AS '%',
    table2.total_2 AS 'Users who like every photo',
    (table2.total_2 / (SELECT COUNT(*) FROM facebook.users u)) * 100 AS '%'
FROM
    (SELECT COUNT(*) AS total_1
    FROM
        (SELECT u.username, c.comment_text
        FROM facebook.users u
        LEFT JOIN facebook.comments c ON u.id = c.user_id
        GROUP BY u.id, c.comment_text
        HAVING comment_text IS NULL) AS users_without_comments) AS table1
JOIN
    (SELECT COUNT(*) AS total_2
    FROM
        (SELECT u.id, u.username, COUNT(u.id) AS total_likes_by_user
        FROM facebook.users u
        JOIN facebook.likes l ON u.id = l.user_id
        GROUP BY u.id, u.username
        HAVING total_likes_by_user = (SELECT COUNT(*) FROM facebook.photos p)) AS users_likes_every_photos) AS table2;

        
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#/15/ Clean URLs of photos posted on the platform*/

  #Approach 1
SELECT 
    SUBSTRING_INDEX(image_url, '/', -1) AS IMAGE_URL
FROM
    facebook.photos;
    
 
#Approach 2
    
    SELECT 
    REVERSE(SUBSTRING_INDEX(REVERSE(image_url), '/', 1)) AS IMAGE_URL
FROM
    facebook.photos;

    
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------    

#/15/ Identify Active Users with High Engagement

WITH UserPhotoCounts AS (
    SELECT u.id AS user_id, COUNT(p.id) AS photo_count
    FROM facebook.users u
    LEFT JOIN facebook.photos p ON u.id = p.user_id
    GROUP BY u.id
),
UserCommentCounts AS (
    SELECT u.id AS user_id, COUNT(c.id) AS comment_count
    FROM facebook.users u
    JOIN facebook.photos p ON u.id = p.user_id
    JOIN facebook.comments c ON p.id = c.photo_id
    GROUP BY u.id
)
SELECT u.username AS user_name, 
       UPC.photo_count AS total_photos, 
       UCC.comment_count AS total_comments
FROM facebook.users u
JOIN UserPhotoCounts UPC ON u.id = UPC.user_id
JOIN UserCommentCounts UCC ON u.id = UCC.user_id
WHERE UPC.photo_count > 10 AND UCC.comment_count > 20
ORDER BY UPC.photo_count DESC, UCC.comment_count DESC;


#/16/find users who have posted photos with specific tags

SELECT
    u.username AS user_name,
    p.image_url AS photo_url,
    pt.photo_tags AS photo_tags
FROM
    users u
JOIN
    photos p ON u.id = p.user_id
JOIN (
    SELECT
        pt.photo_id,
        GROUP_CONCAT(t.tag_name ORDER BY t.tag_name ASC) AS photo_tags
    FROM
        photo_tags pt
    JOIN
        tags t ON pt.tag_id = t.id
    WHERE
        t.tag_name IN ('physics wallah', 'education', 'friends') -- Specify the tags you're interested in
    GROUP BY
        pt.photo_id
) pt ON p.id = pt.photo_id
ORDER BY
    u.username ASC,
    p.created_at DESC
LIMIT 0, 50000;

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#/17/retrive mutual interests between users
WITH MutualInterests AS (
    SELECT
        u1.id AS user_id,
        u2.id AS potential_friend_id,
        GROUP_CONCAT(DISTINCT t1.tag_name ORDER BY t1.tag_name) AS common_interests
    FROM
        users u1
    JOIN
        friendships f ON u1.id = f.user_id
    JOIN
        users u2 ON f.friend_id = u2.id
    LEFT JOIN
        photo_tags pt1 ON u1.id = pt1.photo_id
    LEFT JOIN
        tags t1 ON pt1.tag_id = t1.id
    LEFT JOIN
        photo_tags pt2 ON u2.id = pt2.photo_id
    LEFT JOIN
        tags t2 ON pt2.tag_id = t2.id
    WHERE
        u1.id < u2.id -- Avoid duplicate pairs
        AND t1.tag_name IS NOT NULL
        AND t2.tag_name IS NOT NULL
    GROUP BY
        u1.id, u2.id
    HAVING
        common_interests != ''
)
SELECT
    user_id,
    GROUP_CONCAT(potential_friend_id ORDER BY potential_friend_id) AS potential_friends,
    common_interests
FROM
    MutualInterests
GROUP BY
    user_id, common_interests;
    
    ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    ************************
    #Using Stored Procedures 
	************************  
#/1/The username, image posted, tags used and comments made by a specific user*/

DELIMITER //

CREATE PROCEDURE `UserInfo`(IN userid INT(11))
BEGIN
    SELECT 
        u.id, u.username, p.image_url, c.comment_text, t.tag_name
    FROM
        facebook.users u
    INNER JOIN
        facebook.photos p ON p.user_id = u.id
    INNER JOIN
        facebook.comments c ON c.user_id = u.id
    INNER JOIN
        facebook.photo_tags pt ON pt.photo_id = p.id
    INNER JOIN
        facebook.tags t ON t.id = pt.tag_id
    WHERE
        u.id = userid;
END //

CALL UserInfo(60);
    
    
    
    
    
    






